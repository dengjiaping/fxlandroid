package com.aalife.android;

public final class BuildConfig
{
  public static final boolean DEBUG;
}


/* Location:           D:\fxlandroid\document\app\AALifeNew_v3.1.4\classes_dex2jar.jar
 * Qualified Name:     com.aalife.android.BuildConfig
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */