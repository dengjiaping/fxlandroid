package android.support.v4.media;

public class TransportStateListener
{
  public void onPlayingChanged(TransportController paramTransportController) {}
  
  public void onTransportControlsChanged(TransportController paramTransportController) {}
}


/* Location:           D:\fxlandroid\document\app\AALifeNew_v3.1.4\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.TransportStateListener
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */