package android.support.v4.app;

import android.view.View;

abstract interface FragmentContainer
{
  public abstract View findViewById(int paramInt);
}


/* Location:           D:\fxlandroid\document\app\AALifeNew_v3.1.4\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentContainer
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */