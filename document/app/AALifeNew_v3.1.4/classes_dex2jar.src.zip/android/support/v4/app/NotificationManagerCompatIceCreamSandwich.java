package android.support.v4.app;

class NotificationManagerCompatIceCreamSandwich
{
  static final int SIDE_CHANNEL_BIND_FLAGS = 33;
}


/* Location:           D:\fxlandroid\document\app\AALifeNew_v3.1.4\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.NotificationManagerCompatIceCreamSandwich
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */