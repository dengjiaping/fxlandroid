/** Automatically generated file. DO NOT MODIFY */
package com.baidu.android.voicedemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}