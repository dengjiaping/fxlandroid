
package com.baidu.android.voicedemo;

import android.support.v4.app.ListFragment;
import android.view.View;
import android.widget.ListView;

/**
 * 将语义返回结果用List展现
 * 
 * @author yangliang02
 */
public class CommandListFragment extends ListFragment {
    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
    }
}
