package com.baidu.android.voicedemo;

public class Constants {
    /*
     * 请登录http://developer.baidu.com，注册成为百度开发者，创建应用并开通语音技术服务后，
     * 将对应的ApiKey和SecretKey填写后再测试
     */
    public static final String API_KEY = "LjfQaGXUdnHHGZFBReQBtVGs";

    public static final String SECRET_KEY = "awDw9VbFAAbFFKWDhcthn7MrZv44FQI0";

}
